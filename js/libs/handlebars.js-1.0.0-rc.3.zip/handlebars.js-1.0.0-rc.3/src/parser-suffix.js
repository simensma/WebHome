
// END(BROWSER)

module.exports = handlebars;
